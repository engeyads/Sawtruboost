<div class="relative items-top justify-center min-h-screen bg-white sm:items-center sm:pt-0 ">
    <div id="mainmenu" class="fixed px-6  z-50 top-0 right-0 mainmenu" /*onScroll={handleScroll}* />
    <div class="fixed px-6  sm:block">

        <a href="/">
            <img src=<?php echo e(URL::asset('images/SVG/Logo.svg')); ?> alt='Sawtruboost Logo' class='block h-16 w-auto Logo' />
            <img src=<?php echo e(URL::asset('images/SVG/Logo_Text.svg')); ?> alt='Sawtruboost Logo Text' class="logotext" />
        </a>
        <div class='subject'></div>

    </div>
    <div class="sm:inline-flex justify-center items-center justify-between justify-items-center">
        <div class="links text-gray-700 dark:text-gray-500">
            <ul class='flex text-xl font-bold'>
                <li><a href="">Company Profile</a></li>
                <li><a href="<?php echo e(URL::to('blog')); ?>">Blog</a></li>
                <li>
                    <div class='topmenu2'>
                        <span>Services</span><span class='triangleBlack'></span>
                        <div class='submenu2'>
                            <a href='/services#Digital'>Digital</a>
                            <a href='/services#Consultancy'>Consultancy</a>
                            <a href='/services#GrowthStudies'>Growth Studies</a>
                            <a href='/services#Creativity'>Creativity</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="button_container" id="toggle">
            <span class="top"></span>
            <span class="middle"></span>
            <span class="bottom"></span>
        </div>
    </div>
    <div class="overlay customYellowbg" id="overlay">
        <nav class="overlay-menu">
            <ul>
                <li><a href='<?php echo e(route('about')); ?>'>About Us</a></li>
                <li>
                    <div class='topmenu'><span>Services</span><span class='triangleWhite'></span>
                        <div class='submenu '>
                            <div class="submenuItems flex">
                                <a href='/services#Digital'>Digital</a>
                                <a href='/services#Consultancy'>Consultancy</a>
                                <a href='/services#GrowthStudies'>Growth Studies</a>
                                <a href='/services#Creativity'>Creativity</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li><a href="/">Contact Us</a></li>
                <li><a href="/">People</a></li>
                <li class='extramenu'><a href="<?php echo e(URL::to('blog')); ?>">blog</a></li>
                <li class='extramenu'><a href="/">Company Profile</a></li>
            </ul>
            <div class="col-md-4">

                <select class="form-control changeLang">
                    <option value="en" <?php echo e(session()->get('locale') == 'en' ? 'selected' : ''); ?>>English</option>
                    <option value="ar" <?php echo e(session()->get('locale') == 'ar' ? 'selected' : ''); ?>>Arabic</option>
                    <option value="tr" <?php echo e(session()->get('locale') == 'tr' ? 'selected' : ''); ?>>Turkish</option>
                </select>

            </div>
        </nav>
    </div>
</div>

<?php $__env->startPush('custom-scripts'); ?>

<script type="text/javascript">
    var url = "<?php echo e(route('changeLang')); ?>";



    $(".changeLang").change(function(){

        window.location.href = url + "?lang="+ $(this).val();

    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Projects\Sawtruboost\resources\views////components/header.blade.php ENDPATH**/ ?>