<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <a rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="icon" href="<?php echo e(URL::asset('favicon.ico')); ?>" >

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body dir="<?php echo e(__('messages.direction')); ?>">

    <?php echo $__env->make('../components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <?php echo $__env->make('../components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php echo $__env->make('../components/social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.3/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.3/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.3/ScrollToPlugin.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <?php echo $__env->yieldPushContent('custom-scripts'); ?>
    <script>
        jQuery(function() {
            var tl1 = new TimelineMax(),
                tl2 = new TimelineMax();
            var el1 = jQuery('#rear'),
                el2 = jQuery('#front');

            function on_el1() {
                tl1.to(el1, 40, {
                    ease: Power0.easeNone,
                    x: -2600,
                    repeat: -1
                });
            }

            function on_el2() {
                tl2.to(el2, 30, {
                    ease: Power0.easeNone,
                    x: -2600,
                    repeat: -1
                });
            }

            function start() {
                on_el1();
                on_el2();
            }
            start();
        });
    </script>
</body>

</html>
<?php /**PATH D:\Projects\Sawtruboost\resources\views/layouts/app.blade.php ENDPATH**/ ?>