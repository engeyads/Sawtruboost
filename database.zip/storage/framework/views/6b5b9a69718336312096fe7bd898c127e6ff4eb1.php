<?php $__env->startSection('content'); ?>
    <section class='w-full first customYellowbg' style="direction:ltr">

        <div class='bground'>
            <h1 class="heading">
                <?php echo e(__('messages.CompanyWord')); ?><br />
                <?php echo e(__('messages.CompanyWord2')); ?>


            </h1>
            <button class='btn' style="direction:<?php echo e(__('messages.direction')); ?>">
                <h1>
                    <?php echo e(__('messages.boostnow')); ?>

                </h1>
            </button>
        </div>
        <div class="bird-container bird-container--one">
            <div class="bird bird--one"></div>
        </div>

        <div class="bird-container bird-container--two">
            <div class="bird bird--two"></div>
        </div>

        <div class="bird-container bird-container--three">
            <div class="bird bird--three"></div>
        </div>

        <div class="bird-container bird-container--four">
            <div class="bird bird--four"></div>
        </div>

        
        <div class="boost-container boost-container--one">
            <div class="boost boost--one"></div>
        </div>

        <div class="boost-container boost-container--two">
            <div class="boost boost--two"></div>
        </div>

        <div class="boost-container boost-container--three">
            <div class="boost boost--three"></div>
        </div>

        <div class="boost-container boost-container--four">
            <div class="boost boost--four"></div>
        </div>
    </section>

    <section class='w-full second'>
        <div>
            <center>
                <h2 class='socilaword text-xxl font-bold'><?php echo e(__('messages.socialword')); ?></h2>
            </center>
        </div>
    </section>

    <section class=" third" style="direction:ltr">
        <section id="panels">

            <div id="panels-container">

                <div class="panel-heading absolute">

                    <h2 class="">
                        <?php echo e(__('messages.OURMAGICALBOOSTS2')); ?>

                    </h2>
                </div>
                <article id="panel-1" class="panel w-full">
                    <div class="container1">
                        <div class="">
                            <table>
                                <tbody>
                                    <tr>
                                        <td class="txt">

                                            <h2 class='discription'>
                                                <?php echo e(__('messages.DIGITALMARKETING')); ?></h2>
                                            <p class="step-description">
                                                <?php echo e(__('messages.DIGITALMARKETING2')); ?>

                                            </p>

                                            <div class="pt-8 desc">
                                                <p>
                                                    <?php echo e(__('messages.DIGITALMARKETING3')); ?>

                                                </p>
                                            </div>

                                        </td>
                                        <td class="img">

                                            <img class="" src=<?php echo e(URL::asset('images/digital_marketing.webp')); ?>

                                                alt="" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </article>
                <article id="panel-2" class="panel w=full">
                    <div class="container1">
                        <div class="">
                            <table>
                                <tbody>
                                    <tr>
                                        <td class="txt">
                                            <div class="">
                                                <h2 class='discription'>
                                                    <?php echo e(__('messages.GROWTHSTUDIES')); ?>

                                                </h2>

                                                <p class="step-description">
                                                    <?php echo e(__('messages.GROWTHSTUDIES2')); ?>

                                                </p>

                                                <div class="pt-8 desc">
                                                    <p>
                                                        <?php echo e(__('messages.GROWTHSTUDIES3')); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="img">
                                            <div class="">
                                                <img class="" src=<?php echo e(URL::asset('images/growth_studies.webp')); ?>

                                                    alt="" />
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </article>
                <article id="panel-3" class="panel w=full">
                    <div class="container1">
                        <div class="">
                            <table>
                                <tbody>
                                    <tr>
                                        <td class="txt">
                                            <div class="">
                                                <h2 class='discription'>
                                                    <?php echo e(__('messages.CONSULTANCY')); ?>

                                                </h2>

                                                <p class="step-description">
                                                    <?php echo e(__('messages.CONSULTANCY2')); ?>

                                                </p>

                                                <div class="pt-8 desc">
                                                    <p>
                                                        <?php echo e(__('messages.CONSULTANCY3')); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="img">
                                            <div class="">
                                                <img class="" src=<?php echo e(URL::asset('images/consultancy.webp')); ?>

                                                    alt="" />
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </article>
                <article id="panel-4" class="panel w=full">
                    <div class="container1">
                        <div class="">
                            <table>
                                <tbody>

                                    <tr>
                                        <td class="txt">
                                            <div class="">
                                                <h2 class='discription'>
                                                    <?php echo e(__('messages.INNOVATION')); ?>

                                                </h2>

                                                <p class="step-description">
                                                    <?php echo e(__('messages.INNOVATION2')); ?>

                                                </p>

                                                <div class="pt-8 desc">
                                                    <p>
                                                        <?php echo e(__('messages.INNOVATION3')); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="img">
                                            <div class="">
                                                <img class=""
                                                    src=<?php echo e(URL::asset('images/innovation_&_creativity.webp')); ?>

                                                    alt="" />

                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </article>
            </div>
        </section>
        <!--
            <section id="panelsMobile">
                <h2 class="text-xl mt-32 w-full font-bold fontBlont text-custom-gray ">
                    
                                        alt="" />

                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>


            </section>
        -->
    </section>

    <section class='w-full py-20 fourth'>
        <div>
            <center>
                <table>
                    <tr class="py-4 partners">
                        <td><img src=<?php echo e(URL::asset('images/client1.webp')); ?> width="160px" alt="" /></td>
                        <td><img src=<?php echo e(URL::asset('images/client3.webp')); ?> width="160px" alt="" /></td>
                        <td><img src=<?php echo e(URL::asset('images/client2.webp')); ?> width="160px" alt="" /></td>
                        <td><img src=<?php echo e(URL::asset('images/cybersky.webp')); ?> width="160px" alt="" /></td>
                    </tr>
                </table>
            </center>
        </div>
    </section>

    <section class='w-full yellowbg fifth'>
        <div class="blog-home5 py-5">

            <div class=" justify-content-center">
                <div class="">
                    <center>
                        <h3 class="mb-2"><?php echo e(__('messages.LATESTINSIGHTS')); ?></h3>
                    </center>
                    
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card b-h-box position-relative font-14 border-0 mb-4">
                        <img class="card-img"
                            src=<?php echo e(URL::asset('images/top-view-man-doing-online-shopping-his-laptop.webp')); ?>

                            alt="Card image" />
                        <div class="card-img-overlay overflow-hidden">
                            <div class="d-flex align-items-center">
                                <span
                                    class="bg-danger-gradiant badge overflow-hidden text-white px-3 py-1 font-weight-normal">Admin</span>
                                <div class="ml-2">
                                    <span class="ml-2">Nov 18, 2022</span>
                                </div>
                            </div>
                            <h5 class="card-title my-3 font-weight-normal">Online Consumption: Growing Continually or
                                Just Striking a Plateau?</h5>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card b-h-box position-relative font-14 border-0 mb-4">
                        <img class="card-img"
                            src=<?php echo e(URL::asset('images/business-partners-handshake-international-corporate.webp')); ?>

                            alt="Card image" />
                        <div class="card-img-overlay overflow-hidden">
                            <div class="d-flex align-items-center">
                                <span
                                    class="bg-danger-gradiant badge overflow-hidden text-white px-3 py-1 font-weight-normal">Admin</span>
                                <div class="ml-2">
                                    <span class="ml-2">Nov 18, 2022</span>
                                </div>
                            </div>
                            <h5 class="card-title my-3 font-weight-normal">Which strategy is better for your company:
                                In-House versus outsourcing</h5>
                            <p class="card-text">Explore the fundamentals of marketing to identify whether you should
                                hire a professional or handle your own marketing: Do it yourself or buy it.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card b-h-box position-relative font-14 border-0 mb-4">
                        <img class="card-img"
                            src=<?php echo e(URL::asset('images/man-holding-credit-card-hand-entering-security-code-using-laptop-keyboard.webp')); ?>

                            alt="Card image" />
                        <div class="card-img-overlay overflow-hidden">
                            <div class="d-flex align-items-center">
                                <span
                                    class="bg-danger-gradiant badge overflow-hidden text-white px-3 py-1 font-weight-normal">Charity,
                                    Ngo</span>
                                <div class="ml-2">
                                    <span class="ml-2">Feb 18, 2018</span>
                                </div>
                            </div>
                            <h5 class="card-title my-3 font-weight-normal">Help out the people who really need it on
                                time.</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                eiusmod...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->startPush('custom-scripts'); ?>
        <script>
            gsap.registerPlugin(ScrollToPlugin, ScrollTrigger);

            /* Main navigation */
            let panelsSection = document.querySelector("#panels");
            let panelsContainer = document.querySelector("#panels-container");
            let tween;

            /* Panels */
            const panels = gsap.utils.toArray("#panels-container .panel");
            tween = gsap.to(panels, {
                xPercent: -100 * (panels.length - 1),
                ease: "none",
                scrollTrigger: {
                    trigger: "#panels-container",
                    pin: true,
                    start: "top top",
                    scrub: 1,
                    snap: {
                        snapTo: 1 / (panels.length - 1),
                        inertia: false,
                        duration: {
                            min: 0.1,
                            max: 0.1
                        }
                    },
                    end: () => "+=" + (panelsContainer.offsetWidth - innerWidth)
                }
            });
        </script>
        <script type="module" src="<?php echo e(URL::asset('js/home.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Sawtruboost\resources\views/welcome.blade.php ENDPATH**/ ?>