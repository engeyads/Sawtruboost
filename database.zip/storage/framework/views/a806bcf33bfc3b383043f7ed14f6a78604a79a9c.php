<div class="sticky-icon">
    <a href="#" class="Tiktok">  <i class="fab fa-tiktok"></i></a>
    <a href="https://www.linkedin.com/company/sawtruboost/" class="linkedin">  <i
            class="fab fa-linkedin" aria-hidden="true"></i></a>
    <a href="https://www.instagram.com/sawtruboost/" class="Instagram">  <i
            class="fab fa-instagram"></i></a>
    <a href="https://www.facebook.com/sawtruboost/" class="Facebook">  <i
            class="fab fa-facebook-f"> </i></a>
    <a href="https://twitter.com/sawtruboost" class="Twitter">  <i class="fab fa-twitter">
        </i></a>
    <a href="https://tr.pinterest.com/SAWTRUBOOST/" class="pinterest">  <i
            class="fab fa-pinterest"> </i></a>
</div>
<?php /**PATH D:\Projects\Sawtruboost\resources\views////components/social.blade.php ENDPATH**/ ?>