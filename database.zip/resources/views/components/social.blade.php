<div class="sticky-icon">
    <a href="#" class="Tiktok"> {{-- Tiktok --}} <i class="fab fa-tiktok"></i></a>
    <a href="https://www.linkedin.com/company/sawtruboost/" class="linkedin"> {{-- LinkedIn --}} <i
            class="fab fa-linkedin" aria-hidden="true"></i></a>
    <a href="https://www.instagram.com/sawtruboost/" class="Instagram"> {{-- Instagram --}} <i
            class="fab fa-instagram"></i></a>
    <a href="https://www.facebook.com/sawtruboost/" class="Facebook"> {{-- Facebook --}} <i
            class="fab fa-facebook-f"> </i></a>
    <a href="https://twitter.com/sawtruboost" class="Twitter"> {{-- Twitter --}} <i class="fab fa-twitter">
        </i></a>
    <a href="https://tr.pinterest.com/SAWTRUBOOST/" class="pinterest"> {{-- Twitter --}} <i
            class="fab fa-pinterest"> </i></a>
</div>
