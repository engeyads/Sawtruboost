@extends('layouts.app')

@section('content')
    <section class='w-full second'>
        <div>
            <p>
                <a href="https://tabpanelwidget.com">
                    TabPanelWidget</a> is a Semantic, Accessible, Responsive, and Versatile solution to create Tabpanel and
                Accordion Widgets for the Web.<br>
                <a href="https://tabpanelwidget.com">
                    Check it out!</a>
            </p>
            <h1 class="">Pure CSS Tab Panel</h1>
            <p>This is mostly a proof of concept. Remember that most "Pure CSS" solutions are rarely Accessible.</p>
            <div class="tabPanel-widget">
                <label for="tab-1" tabindex="0"></label>
                <input id="tab-1" type="radio" name="tabs" checked="true" aria-hidden="true">
                <h2>Strong</h2>
                <div>
                    <p>Represents strong importance for its contents. Indicate relative importance by nesting strong
                        elements; each strong element increases the importance of its contents. Changing the importance of a
                        piece of text with the strong element does not change the meaning of the sentence.</p>
                    <p>Source: <a href="http://html5doctor.com/element-index/">html5doctor</a> for Strong</p>
                </div>
                <label for="tab-2" tabindex="0"></label>
                <input id="tab-2" type="radio" name="tabs" aria-hidden="true">
                <h2>Section</h2>
                <div>
                    <p>Represents a generic document or application section. In this context, a section is a thematic
                        grouping of content, typically with a header, possibly with a footer. Examples include chapters in a
                        book, the various tabbed pages in a tabbed dialog box, or the numbered sections of a thesis. A web
                        site's home page could be split into sections for an introduction, news items, contact information.
                    </p>
                    <p>Source: <a href="http://html5doctor.com/element-index/">html5doctor</a> for Section</p>
                </div>
                <label for="tab-3" tabindex="0"></label>
                <input id="tab-3" type="radio" name="tabs" aria-hidden="true">
                <h2>Source</h2>
                <div>
                    <p>The source element allows authors to specify multiple alternative media resources for media elements.
                        It does not represent anything on its own. The src attribute gives the address of the media
                        resource. The value must be a valid non-empty URL potentially surrounded by spaces. This attribute
                        must be present.</p>
                    <p>Source: <a href="http://html5doctor.com/element-index/">html5doctor</a> for Source</p>
                </div>
            </div>
            <p>This <a href="http://cssmojo.com">link</a> is here to better test sequential navigation.</p>
        </div>
    </section>
    @push('custom-scripts')
        <script type="module" src="{{ URL::asset('js/home.js') }}"></script>
    @endpush
@endsection
